/*    function build(radius, height, segments, color, color2){
        let vertices = segments * 18;

        let attributes = Seq.with(
                VertexAttribute.position3,
                packNormals ? VertexAttribute.packedNormal : VertexAttribute.normal,
                VertexAttribute.color
        );

        mesh = new Mesh(true, vertices, 0, attributes.toArray(VertexAttribute.class));
        mesh.getVerticesBuffer().limit(mesh.getVerticesBuffer().capacity());
        mesh.getVerticesBuffer().position(0);

        let buf = mesh.getVerticesBuffer();
        buf.clear();

        let stride = packNormals ? 5 : 7;
        let floats = new [stride];

        let half = height / 2f;

        for(let i = 0; i < segments; i++){
            let col = (i % 4 == 0 ? color : color2).toFloatBits();

            let a1 = i / segments * Mathf.PI2;
            let a2 = (i + 1) / segments * Mathf.PI2;

            let p1  = new Vec3(Mathf.cos(a1) * radius * 1.0f,  half, Mathf.sin(a1) * radius * 1.0f);
            let p2  = new Vec3(Mathf.cos(a2) * radius * 1.0f,  half, Mathf.sin(a2) * radius * 1.0f);
            let p3  = new Vec3(Mathf.cos(a2) * radius * 1.0f, -half, Mathf.sin(a2) * radius * 1.0f);
            let p4  = new Vec3(Mathf.cos(a1) * radius * 1.0f, -half, Mathf.sin(a1) * radius * 1.0f);

            let innerR = radius * 0.9675f;

            let p5  = new Vec3(Mathf.cos(a1)*innerR,  half, Mathf.sin(a1)*innerR);
            let p6  = new Vec3(Mathf.cos(a2)*innerR,  half, Mathf.sin(a2)*innerR);

            let p7 = new Vec3(Mathf.cos(a2)*innerR, -half, Mathf.sin(a2)*innerR);
            let p8 = new Vec3(Mathf.cos(a1)*innerR, -half, Mathf.sin(a1)*innerR);

            let normalOuter = new Vec3(p1.x, 0, p1.z).nor();

            vert(buf, floats, p1, normalOuter, col);
            vert(buf, floats, p2, normalOuter, col);
            vert(buf, floats, p3, normalOuter, col);

            vert(buf, floats, p1, normalOuter, col);
            vert(buf, floats, p3, normalOuter, col);
            vert(buf, floats, p4, normalOuter, col);

            let normalUp = new Vec3(0, -1, 0);

            vert(buf, floats, p1, normalUp, col);
            vert(buf, floats, p2, normalUp, col);
            vert(buf, floats, p6, normalUp, col);

            vert(buf, floats, p1, normalUp, col);
            vert(buf, floats, p6, normalUp, col);
            vert(buf, floats, p5, normalUp, col);

            let normalDown = new Vec3(0, 1, 0);

            vert(buf, floats, p8, normalDown, col);
            vert(buf, floats, p7, normalDown, col);
            vert(buf, floats, p3,  normalDown, col);

            vert(buf, floats, p8, normalDown, col);
            vert(buf, floats, p3,  normalDown, col);
            vert(buf, floats, p4,  normalDown, col);
        }

        mesh.getVerticesBuffer().limit(mesh.getVerticesBuffer().position());
        return mesh;
    }

    function vert(buf, floats, p, normal, color){
        floats[0] = p.x;
        floats[1] = p.y;
        floats[2] = p.z;

        if(packNormals){
            floats[3] = packNormal(normal.x, normal.y, normal.z);
            floats[4] = color;
        }else{
            floats[3] = normal.x;
            floats[4] = normal.y;
            floats[5] = normal.z;
            floats[6] = color;
        }

        buf.put(floats);
    }

    function packNormal(x, y, z){
        let xs = x < -1f/512f ? 1 : 0;
        let ys = y < -1f/512f ? 1 : 0;
        let zs = z < -1f/512f ? 1 : 0;

        let vi =
                zs << 29 | ((z * 511 + (zs << 9)) & 511) << 20 |
                        ys << 19 | ((y * 511 + (ys << 9)) & 511) << 10 |
                        xs << 9  | ((x * 511 + (xs << 9)) & 511);

        return Float.intBitsToFloat(vi);
    }
function starRingMesh(planet, radius, height, seed, color, color2) {
        this.planet = planet;
        this.mesh = build(radius, height, 120, color, color2);
        this.shaders = Shaders.clouds;
        rand.setSeed(seed);
        flipValue = rand.random(-180, 180);
        flipAngle.setToRandomDirection(rand);
        flipSpeed = rand.random(0.3, 0.7);
        rotateSpeed = rand.random(1, 3);
    };
function render(params, projection, transform){
        if(params.planet == planet && Mathf.zero(1 - params.uiAlpha, 0.01)) return;

        preRender(params);
        shader.bind();
        shader.setUniformMatrix4("u_proj", projection.val);
        shader.setUniformMatrix4("u_trans", mat
                .setToTranslation(planet.position)
                .rotate(flipAngle, flipRot())
                .rotate(Vec3.Y, planet.getRotation() + relRot()).val);
        shader.apply();
        mesh.render(shader, Gl.triangles);
    };
    function preRender(params){
        Shaders.clouds.planet = planet;
        Shaders.clouds.lightDir.set(planet.solarSystem.position).sub(planet.position)
                .rotate(flipAngle, flipRot())
                .rotate(Vec3.Y, planet.getRotation() + relRot())
                .nor();
        Shaders.clouds.ambientColor.set(planet.solarSystem.lightColor);
        Shaders.clouds.alpha = params.planet == planet ? 1 - params.uiAlpha : 1;
    };*/
//这些方法来自Oblivion_Engine-mod，Todo
exports.starRingMesh = starRingMesh;
//error, hasnt use, Todo(?)