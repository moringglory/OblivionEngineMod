const ln = require("log");
Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#E3A876FF]废土科技");//新建一个显示窗
	var dv = 0;
	var dialogTitle = "";
	dialog.cont.pane(table => {
		var titleRand
		var titleRandVar = Math.floor(Math.random() * 5);
		for (let i = 0; i < 6; i++) {
		titleRandVar = Math.floor(GlobalVars.rand.nextDouble() * 7);//神金...
		};

	switch (titleRandVar) {
		case 0:titleRand="试试铁锈战争!"
		break;
		case 1:titleRand="加入了114514个虫族建筑!"
		break;
		case 2:titleRand="[#c000c0]Uzi:这种破活凭啥我也得掺一脚"
		break;
		case 3:titleRand="[#0044ff]你知道蒙诺埃斯诺吗?"
		break;
		case 4:titleRand="我们修复了114514个bug!"
		break;
		case 5:titleRand="玩玩赤石科技让你烂手回冬!"
		break;
		case 6:titleRand="重制了33550336个贴图"
		break;
	};
		ln.thislog(1, "随机标题:"+titleRand, "("+titleRandVar+"号)")

		table.add("关于本mod\n\nmod仅支持153及以上版本\nmod暂不公开传播需经作者允许,本mod拥有部分故事背景,以出现\n灾难的星球帝科斯基为背景,数个围绕灾难的主线地图将由\n你探索\n\n[red]本mod可能会出现大量重复色系的高饱和度颜色,易引起审\n美疲劳\n[#ffffffff]可以向QQ号[#0000ffff]3958138991[#ffffffff]提出建议,申请好友请备注“建\n议”\n\n[red]目前开放地图: []废墟古城, 猩红起始地段, 陡峭岩崖, \n对峙狭廊\n[red]⚠⚠⚠所有小于等于beta0.6.8(0.0.068)版本的\n拥有此mod建筑的地图因为模组核心文件迭代原因\n在beta0.6.8(0.0.068)以后加载崩溃[#ffe262]\n\n"+titleRand)
		table.row();
	})
	
	dialog.buttons.button("[#c000c0](看看注意事项!)关闭", run(() => {
		dialog.hide()//退出此界面
		ln.thislog(1, "已关闭菜单", "")
	})).size(110, 64);//按钮用原版@close
	//贴图size（长,宽）
	
	dialog.buttons.button("[#c02020]注意事项", run(() => {
		var dialog2 = new BaseDialog('注意事项');
		ln.thislog(1, "打开注意事项", "")
		dialog2.cont.pane(table => {
			table.add("菜单是可以划的!!!\n\n1.由于版本更新因素可能导致多配方工厂使用时致使您的游戏卡\n一下，但不要担心，不会导致游戏崩溃\n\n2.由于未知原因带资源默认会带铅和铜,发射核心时需要点击核\n心图标以恢复正常\n\n3.目前因为技术原因无法制作本星球的数字区块生成\n\n[red]4.极少数人可能会在游玩本mod时，因mod中的闪光或图形出\n现癫痫症状，即便没有癫痫病史也可能出现类似状况。这些症状\n包含眼睛疼痛、视觉异常、偏头痛、痉挛、意识障碍（如昏迷）\n等。若游玩过程中出现上述症状，请立即停止游戏并就医。若您\n或亲属有癫痫病史，游玩前建议咨询医生。同时，可通过坐远屏\n幕、使用小屏幕设备、保持环境明亮、避免疲劳时游戏等方式降\n低风险"/*区块旁的数字区块十分庞大,发射核心至数字区块时,需在进入区块加载页面时大退,重新打开游戏并重新进入区块并等待\n[red]请勿在获得建筑“资源转化器”与“资源发射器”前进入数字区块,并且进入数字区块前必须带超过1k的黄铜、铁、废料,否则无法正常游玩本mod星球的数字区块*/)
		})
		dialog2.buttons.defaults().size(210, 64);
		dialog2.buttons.button("关闭", run(() => {
			dialog2.hide()//退出此界面
			ln.thislog(1, "已关闭注意事项", "")
		})).size(110, 64);
		dialog2.show();
	})).size(110, 64);

	dialog.buttons.button("[#ffe262]制作人员", run(() => {
		var dialog3 = new BaseDialog('制作人员');
		ln.thislog(1, "已打开制作人员列表", "")
		dv++;
		if(7<=dv&&dv<13){
			dialogTitle = "[#ffe262]这里没有开发者模式[]\n"
		}else if(13<=dv&&dv<25){
			dialogTitle = "[#ffe262]这里真的没有开发者模式[]\n"
		}else if(25<=dv&&dv<50){
			dialogTitle = "[#ffe262]你究竟在找什么[]\n"
		}else if(50<=dv&&dv<51){
			dialogTitle = "[#ffe262]逆天[]\n"
		}else if(51<=dv){
			dialogTitle = "[#ffe262]希望你玩得开心\n目前已按"+dv+"次[]\n"
		};//神经
		
		dialog3.cont.pane(table => {
		table.add(dialogTitle+"[#ffe262]贴图：UPTEN-C814&AL-1S天童爱丽丝\n地图：UPTEN-C814&AL-1S天童爱丽丝\n音乐：来自Re-Logic/Jeff的lunch\n来自bilibili的\"11与27\"menu\n目前原作者不明确的game1~3\n对于音乐我不用做商用，希望原作者见谅\n如有冒犯，会立即删除\n智械名单:\ncreative\n火星人076\n为本mod做出贡献的人可以在此留名\n向先驱致以崇高敬意\n剧情人物: [#c000c0]Uzi•Doorman[][]&[#c02020]Doll[]&[#ffe262]Cyn[]&[#ffe262]N[]&[#ffe262]V[]&[#0080ff]Temsys\n[]&[#00ffff]Add[]&[#008080]Del\n\n\n[#c000c0]U < Gotta put our names down too?\nWe're just fictional characters, y'know?\n\n[#ffe262]V < Our creator who denies themselves must\nhave lost their mind\n\nN < Wait, I get to be on it too? That’s cool!\n\nCyn < Just write ’em, hurry up—got roasted\nbatteries to eat.")
		})
		dialog3.buttons.defaults().size(210, 64);
		dialog3.buttons.button("关闭", run(() => {
			dialog3.hide()//退出此界面
			ln.thislog(1, "已关闭制作人员列表", "")
		})).size(110, 64);
		dialog3.show();
	})).size(110, 64);
	dialog.show();
}))
/*结构
1（2，3）
*/