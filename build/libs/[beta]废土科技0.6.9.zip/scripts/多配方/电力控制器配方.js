const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 电力控制器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "电力控制器", [
	{
		input: {},
		output: {
			power: 1/60
		},
		craftTime: 60
	},
		{
		input: {},
		output: {
			power: 5/60
		},
		craftTime: 60
	},
	{
		input: {},
		output: {
			power: 10/60
		},
		craftTime: 60
	},
	{
		input: {},
		output: {
			power: 50/60
		},
		craftTime: 60
	},
	{
		input: {},
		output: {
			power: 100/60
		},
		craftTime: 60
	},
	{
		input: {},
		output: {
			power: 500/60
		},
		craftTime: 60
	},
	{
		input: {},
		output: {
			power: 1000/60
		},
		craftTime: 60
	},
]);