const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 初等计算器 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "初等计算器", [
	{
		input: {
			power: 2
		},
		output: {
			liquids: ["废土科技-数据流/10"]
		},
		stages: [
			{
				title: "传入数据@minor 通过小型局域网连接传入需计算数据",
				bartitle: "传入中",
				input: ["电力"],
				output: ["传入数据"]
			},
			{
				title: "计算数据@minor 通过内置简单GPU计算需计算数据",
				bartitle: "计算中",
				input: ["电力 + 传入数据"],
				output: ["已计算数据"]
			},
			{
				title: "传出数据@minor 由于技术限制通过特殊流体传出数据",
				bartitle: "传出中",
				input: ["电力 + 已计算数据数据"],
				output: ["数据流"]
			},
		],
		craftTime: 600,
	},
])