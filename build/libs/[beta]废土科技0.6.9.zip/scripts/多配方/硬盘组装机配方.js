const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 硬盘组装机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "硬盘组装机", [
	{
		input: {
			items: [
				"废土科技-安山合金/1",
				"废土科技-铁/1"
			],
			power: 3
		},
		output: {
			items: ["废土科技-空白数据硬盘/6", ]
		},
		craftTime: 720
	},
])