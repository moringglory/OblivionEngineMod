const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");

const 初代实验室 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "初代实验室", [
	{
		input: {
			items: ["废土科技-空白数据硬盘/1"],
			liquids:["废土科技-数据流/1"],
			power: 5,
		},
		output: {
			items: ["废土科技-初阶数据硬盘/1"]
		},
		craftTime: 60
	},
])