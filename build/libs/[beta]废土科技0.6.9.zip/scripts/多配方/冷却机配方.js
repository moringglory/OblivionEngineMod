const library = require("library");
const myliquids = require("分类/物品");
const myitems = require("分类/物品");
const 冷却机 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "冷却机", [
	{
		input: {
			liquids: [
			"废土科技-熔融铜/24",
			"废土科技-水/24"
			],
			power: 1
		},
		output: {
			items: [
			"废土科技-黄铜/20",
			"废土科技-废料/4"
			]
		},
		stages: [
			{
				title: "离心金属液@minor 使用特殊科技离心金属",
				bartitle: "离心中",
				input: ["熔融粗铜"],
				output: ["熔融铜 + 废液"]
			},
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["熔融铜 + 废液"],
				output: ["黄铜 + 废料"]
			},
		],
		craftTime: 120
	},
	{
		input: {
			liquids: [
			"废土科技-熔融铁/24",
			"废土科技-水/24"
			],
			power: 1
		},
		output: {
			items: [
			"废土科技-铁/20",
			"废土科技-废料/4"
			]
		},
		stages: [
			{
				title: "离心金属液@minor 使用特殊科技离心金属",
				bartitle: "离心中",
				input: ["熔融粗铁"],
				output: ["熔融铁 + 废液"]
			},
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["熔融铁 + 废液"],
				output: ["铁 + 废料"]
			},
		],
		craftTime: 120
	},
	{
		input: {
			liquids: [
			"废土科技-熔融金/24"
			],
			items: [
			"废土科技-冰/16"
			],
			power: 1
		},
		output: {
			items: [
			"废土科技-金/20",
			"废土科技-废料/6"
			]
		},
		stages: [
			{
				title: "离心金属液@minor 使用特殊科技离心金属",
				bartitle: "离心中",
				input: ["熔融粗金"],
				output: ["熔融金 + 废液"]
			},
			{
				title: "冷却金属液@minor 使用特殊科技冷却金属",
				bartitle: "冷却中",
				input: ["熔融金 + 废液"],
				output: ["金 + 废料"]
			},
		],
		craftTime: 120
	}
]);