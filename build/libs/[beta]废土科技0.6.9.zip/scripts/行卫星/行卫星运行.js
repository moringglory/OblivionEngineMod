const ln = require("log");
try {
    require("行卫星/德克科");
    require("行卫星/帝科斯基");//加载代码
    require("行卫星/死命");
} catch (error) {
    ln.thislog(3, "星球加载或执行失败,原因:", error);
    ln.thislog(1, "已跳过星球模块，继续执行下一个js","");
}
ln.thislog(1, "所有行星及其子卫星加载完成","")
require("行卫星/地图树");
ln.thislog(1, "地图树加载完成", "")