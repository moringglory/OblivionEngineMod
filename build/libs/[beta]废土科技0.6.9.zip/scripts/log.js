var writer=Core.settings.getDataDirectory().child("废土.md").writer(false);//在last_log同级页面生成.md后缀日志
writer.write("_#废土科技日志#_")//存储文本至缓存
writer.flush();//打印文本
function thislogWarn(log){
    writer.write("\n[Warn]"+Date.now()+"ms:"+log)//Date.now，系统时间戳，单位ms
    writer.flush();
};//此方法在旨快速报错
function thislog(level, log, error){
    var Lv
    switch(level){//若level为x，则Lv=
        case 0:Lv="";break;
        case 1:Lv="`[Info]`";break;
        case 2:Lv="[Warn]";break;
        case 3:Lv="#[Error]#";break;
        default:{
            Lv="[Unallocated]";//若日志等级不属于以上值
            thislogWarn("无法理解的日志等级");
        }
    }
    writer.write("\n"+Lv+Date.now()+"ms:"+log+error)//[Lv]114514ms:我是说明，我是错误
    writer.flush();
};
exports.thislogWarn=thislogWarn//输出方法
exports.thislog=thislog
//调用方法，ln/*(变量名，只要不与其它输出的变量名相同就行)*/=require("log.js路径");