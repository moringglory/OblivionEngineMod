//#11参考PartMove(PartProgress progress, float x, float y, float rot)
//
function myDrawTurret(barrelX, retractionY, suffix) {
    return extend(DrawTurret, {
        load() {
            DrawTurret.prototype.load.call(this);
            this.parts.add(
                new extend(RegionPart, {
                    load() {
                        RegionPart.prototype.load.call(this);
                        this.region = Core.atlas.find(this.parent.name + suffix);
                        this.progress = PartProgress.reload;
                        this.under = true;
                        this.mirror = false;
                        this.layerOffset = -0.003;
                        this.x = 0;
                        this.y = 0;
                        this.moves.add(
                            new PartMove(PartProgress.reload * PartProgress.reload, 0, -retractionY, 0),
                            new PartMove((PartProgress.reload * PartProgress.reload * -0.5 + PartProgress.reload) * 2, -barrelX, 0, 0)
                        );
                    }
                }),
                new extend(RegionPart, {
                    load() {
                        RegionPart.prototype.load.call(this);
                        this.region = Core.atlas.find(this.parent.name + suffix);
                        this.progress = PartProgress.reload;
                        this.under = true;
                        this.mirror = false;
                        this.layerOffset = -0.002;
                        this.x = barrelX;
                        this.y = -retractionY;
                        this.moves.add(
                            new PartMove(PartProgress.reload * PartProgress.reload, -barrelX, 0, 0),
                            new PartMove((PartProgress.reload * PartProgress.reload * -0.5 + PartProgress.reload) * 2, 0, retractionY, 0)
                        );
                    }
                }),
                new extend(RegionPart, {
                    load() {
                        RegionPart.prototype.load.call(this);
                        this.region = Core.atlas.find(this.parent.name + suffix);
                        this.progress = PartProgress.reload;
                        this.under = true;
                        this.moves.add(
                            new PartMove(PartProgress.reload * PartProgress.reload, 0, retractionY, 0),
                            new PartMove((PartProgress.reload * PartProgress.reload * -0.5 + PartProgress.reload) * 2, barrelX, 0, 0)
                        );
                    }
                }),
                new extend(RegionPart, {
                    load() {
                        RegionPart.prototype.load.call(this);
                        this.region = Core.atlas.find(this.parent.name + suffix);
                        this.progress = PartProgress.reload;
                        this.under = true;
                        this.moves.add(
                            new PartMove(PartProgress.reload * PartProgress.reload, barrelX, 0, 0),
                            new PartMove((PartProgress.reload * PartProgress.reload * -0.5 + PartProgress.reload) * 2, 0, -retractionY, 0)
                        );
                    }
                })
            );
        }
    });
}
exports.myDrawTurret = myDrawTurret;