var a = "已加载: "
function newItem(name) {
	exports[name] = extend(Item, name, {});
	a = a + name + ", "
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
	a = a + name + ", "
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
	a = a + name + ", "
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
	a = a + name + ", "
}
//Item——————————————————
const ln = require("log")
newItem("废料")
newItem("粗铜")
newItem("黄铜")
newItem("粗金")
newItem("金")
newItem("精密构件")
newItem("安山岩")
newItem("安山合金")
newItem("铁")
newItem("沉晶岩")
newItem("锶晶石")
newItem("钢")
newItem("碳")
newItem("猩红藻")
newItem("钢化玻璃")
newItem("绿藻")
newItem("铜板")
newItem("铁板")
newItem("金板")
newItem("空白数据硬盘")
newItem("初阶数据硬盘")
newItem("二阶数据硬盘")
newLiquid("水")
newLiquid("熔融铜")
newLiquid("熔融铁")
newLiquid("熔融金")
newLiquid("有机溶液")
newLiquid("熔液")
newLiquid("石油")
newLiquid("二氧化碳")
newLiquid("数据流")
newBlock("最高访问协议")
newBlock("科技_原始")
newBlock("科技_工业")
newBlock("成就_地图_1")

ln.thislog(1, a, "")